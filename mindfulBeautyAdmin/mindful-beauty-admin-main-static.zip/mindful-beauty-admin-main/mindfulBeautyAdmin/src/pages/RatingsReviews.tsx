import { RatingReviewsTable } from "@/components/RatingsReviews/RatingReviewsTable"

export const RatingsReviews = () => {
  return (
    <div>
      <RatingReviewsTable />
    </div>
  )
}

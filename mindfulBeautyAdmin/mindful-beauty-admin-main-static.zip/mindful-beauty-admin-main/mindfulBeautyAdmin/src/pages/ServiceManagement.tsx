import { Outlet } from 'react-router-dom'

export const ServiceManagement = () => {
  return (
    <div>
      <Outlet />
    </div>
  )
}
